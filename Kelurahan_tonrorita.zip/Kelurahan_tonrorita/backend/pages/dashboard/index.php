<?php
include '../../partials/header.php';
include '../../partials/sidenav.php';
include '../../partials/navbar.php';
require_once __DIR__ . '/../../../config/connection.php';

// ====== HITUNG DATA ======
$qProfil = mysqli_query($connect, "SELECT COUNT(*) AS total FROM profil_kelurahan");
$jumlahProfil = mysqli_fetch_assoc($qProfil)['total'];

$qBerita = mysqli_query($connect, "SELECT COUNT(*) AS total FROM berita");
$jumlahBerita = mysqli_fetch_assoc($qBerita)['total'];

$qKontak = mysqli_query($connect, "SELECT COUNT(*) AS total FROM kontak");
$jumlahKontak = mysqli_fetch_assoc($qKontak)['total'];

$qKontakBelum = mysqli_query($connect, "SELECT COUNT(*) AS total FROM kontak WHERE status = 'belum_dibaca'");
$jumlahKontakBelum = mysqli_fetch_assoc($qKontakBelum)['total'];

$qKontakDibalas = mysqli_query($connect, "SELECT COUNT(*) AS total FROM kontak WHERE status = 'dibalas'");
$jumlahKontakDibalas = mysqli_fetch_assoc($qKontakDibalas)['total'];
?>

<div class="page-wrapper" style="margin-left:70px; min-height:100vh; background-color:#f8f9fa;">
    <div class="container-fluid py-4">
        <h3 class="mb-4 fw-bold">Dashboard Website Profil Kelurahan</h3>

        <!-- Cards -->
        <div class="row g-4 mb-4">

            <!-- Profil Kelurahan -->
            <div class="col-sm-6 col-lg-4">
                <a href="../profil_kelurahan/index.php" class="text-decoration-none">
                    <div class="card text-white bg-primary shadow-sm border-0 h-100">
                        <div class="card-body d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-1 text-white">Profil Kelurahan</h6>
                                <h2 class="fw-bold text-white"><?= $jumlahProfil ?></h2>
                            </div>
                            <i class="material-icons fa-2x opacity-75">apartment</i>
                        </div>
                    </div>
                </a>
            </div>

            <!-- Berita -->
            <div class="col-sm-6 col-lg-4">
                <a href="../berita/index.php" class="text-decoration-none">
                    <div class="card text-white bg-success shadow-sm border-0 h-100">
                        <div class="card-body d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-1 text-white">Berita</h6>
                                <h2 class="fw-bold text-white"><?= $jumlahBerita ?></h2>
                            </div>
                            <i class="material-icons fa-2x opacity-75">feed</i>
                        </div>
                    </div>
                </a>
            </div>

            <!-- Kontak -->
            <div class="col-sm-6 col-lg-4">
                <a href="../kontak/index.php" class="text-decoration-none">
                    <div class="card text-white bg-warning shadow-sm border-0 h-70">
                        <div class="card-body d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-1 text-white">Pesan Masuk</h6>
                                <h2 class="fw-bold text-white"><?= $jumlahKontak ?></h2>
                            </div>
                            <i class="material-icons fa-2x opacity-75">contact_mail</i>
                        </div>
                    </div>
                </a>
            </div>
        </div>

        <!-- Grafik Kontak -->
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body">
                <h5 class="card-title mb-4">Status Pesan Kontak</h5>
                <canvas id="kontakChart" height="60"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('kontakChart').getContext('2d');
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Belum Dibaca', 'Dibalas'],
            datasets: [{
                data: [<?= $jumlahKontakBelum ?>, <?= $jumlahKontakDibalas ?>],
                backgroundColor: ['#ffc107', '#28a745'],
                borderColor: ['#ffffff', '#ffffff'],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
</script>

<?php
include '../../partials/footer.php';
include '../../partials/script.php';
?>