<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "personal_profile";
$connect = new mysqli($host, $username, $password, $dbname) or die(mysqli_error($connect));

?>